# MezoTransactionTool 🚀🔥
A LangChain tool for sending BTC and mUSD transactions on Mezo Matsnet. Major degen swag. 

## Installation
```bash
pip install mezoTransactionTool